# YUCLAW commitment research export — verification

Export `exp-1ec5c2f3e3b5e006` built 2026-09-20T07:04:15.694935Z for claim `ZZFX-FY2026-REV-GUIDE` (candidate commit: not recorded).
Canonical research digest: `564cc30e4a02fe99538941f6e76ee081fc4d80614e7d960951c055add71d279d` (sha256 of canonical.json; the export id and built-at time are outside it).

## Verify without an account or a service
```
python3 -m v8.workbench verify-export <this zip>
```
or open the workbench of a FRESH workspace, choose "Verify an export" and upload this zip. Both paths refuse unsafe archives,
check every digest and length, re-derive every claim digest and event hash, and recompute the calculations from the packed
versions and outcome. A changed payload fails with the first discrepancy named.

## Files
| path | sha256 | bytes |
|---|---|---|
| canonical.json | 564cc30e4a02fe99538941f6e76ee081fc4d80614e7d960951c055add71d279d | 12218 |
| schemas/CommitmentClaim.v1.json | cecf69747fd14b93be453bf0e9459a2d75b68eb74600c4dce019230a4ed60aec | 4751 |

## Limitations
- Research content only: claim versions, source references (digests; excerpts only where rights allow), events, method and results. No filing bodies, no market data, no private workspace paths.
- Verification establishes exact bytes and recomputes the supported calculations; it does not establish scientific validity, source authenticity, independence or any investment conclusion.
- Source digests bind bytes; they do not prove publisher authenticity.
- The claim statement is the researcher's authored restatement; verbatim quotations belong in the excerpt, where the rights rule is enforced.
- An export is not a backup, a disaster-recovery copy or a publication. Backup creation and restoration are not provided in 8.0.0.
- Fictional fixture data is a demonstration, never a dataset product whose quality has been established.
- Research notes are authored text with an actor LABEL: attribution that establishes neither authenticated identity nor independent human review; a note changes no claim field and grants no publication eligibility.
- Scientific records are replays of bounded journal inputs through the adapted kernel: the report is recomputed from the packed events; it establishes record consistency and the kernel's statistics under its stated assumptions, never source truth, independent review, authenticated timing or prospective commitment.
- A dataset row is derived from stored records; eligibility is a recorded note, not a criteria run; retrospective rows are reconstructions, not prospective evidence.
- Research and education only. Not investment advice.
